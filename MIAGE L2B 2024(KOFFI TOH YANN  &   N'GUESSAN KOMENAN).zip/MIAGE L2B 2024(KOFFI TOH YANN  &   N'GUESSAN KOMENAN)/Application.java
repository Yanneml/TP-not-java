package ma.L2MIAGE.projet.test;

import ma.L2MIAGE.projet.classes.Etudiant;
import ma.L2MIAGE.projet.classes.Employe;
import ma.L2MIAGE.projet.classes.Professeur;

public class Application {
    public static void main(String[] args) {

        Etudiant etudiant1 = new Etudiant("OBAKA", "Med", "65678754");
        Etudiant etudiant2 = new Etudiant("ALSENY", "Thomas", "87543543");

        Employe employe1 = new Employe("DOUK", "Rachid", 10000.0);
        Employe employe2 = new Employe("NGOYE", "Roland", 10000.0);

        Professeur professeur1 = new Professeur("OBA", "Kevin", 5700.0, "JAVA/JEE");
        Professeur professeur2 = new Professeur("MAGASSOUBA", "Cheick", 5000.0, "Mathématique");

        System.out.println("La liste des employés :");
        System.out.println(employe1);
        System.out.println(employe2);

        System.out.println("\nLa liste des étudiants :");
        System.out.println(etudiant1);
        System.out.println(etudiant2);

        System.out.println("\nLa liste des professeurs :");
        System.out.println(professeur1);
        System.out.println(professeur2);
    }
}
