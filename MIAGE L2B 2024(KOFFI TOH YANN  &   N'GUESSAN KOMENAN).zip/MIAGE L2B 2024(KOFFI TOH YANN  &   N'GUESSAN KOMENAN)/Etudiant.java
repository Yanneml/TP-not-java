
package ma.L2MIAGE.projet.classes;

public class Etudiant extends Personne {
    private String CNE;

    public Etudiant(String nom, String prenom, String CNE) {
        super(nom, prenom);
        this.CNE = CNE;
    }

    @Override
    public String toString() {
        return super.toString() + " mon CNE est: " + CNE;
    }
}
