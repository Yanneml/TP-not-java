package ma.L2MIAGE.projet.classes;

public class Personne {
    protected String nom;
    protected String prenom;

    public Personne(String nom, String prenom) {
        this.nom = nom;
        this.prenom = prenom;
    }

    @Override
    public String toString() {
        return "Je suis " + nom + " " + prenom;
    }
}
